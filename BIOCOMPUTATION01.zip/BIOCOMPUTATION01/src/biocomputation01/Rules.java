/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biocomputation01;

import java.util.Arrays;

/**
 *
 * @author Frostyblade
 */
public class Rules {
    private int rule[] = new int[6];
    private int action = 0;

    public Rules() {
    }
    
    public void setElement(int index, int value){
        rule[index] = value;
    }
    
    public int getElement(int index){
        return rule[index];
    }

    public int[] getRule() {
        return rule;
    }

    public void setRule(int[] rule) {
        this.rule = rule;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }
   
    @Override
    public String toString() {
        String ruleString = "";
        for (int i = 0; i < rule.length; i++){
            ruleString = ruleString + Integer.toString(getElement(i));
        }
        return ruleString;
    
    }

    
}
