/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biocomputation01;


/**
 *
 * @author t4-wang
 */
public class Individual {

    private int gene[] = new int[Genetic01.N];
    private int fitness = 0;

    public Individual() {
    }

    public int[] getGene() {
        return gene;
    }
    
    public int getElement(int index){
        return gene[index];
    }
    
    public String getString(int index){
        String rule = "";
        rule = Integer.toString(gene[index]);
        return rule;
    }

    public void setGene(int[] gene) {
        this.gene = gene;
    }
    
    public void setElement(int index, int value){
        gene[index] = value;
    }

    public int getFitness() {
        return fitness;
    }

    public void setFitness(int fitness) {
        this.fitness = fitness;
    }

    @Override
    public String toString() {
        String geneString = "";
        for (int i = 0; i < gene.length; i++){
            geneString += getElement(i);
        }
        return geneString;
    }
    
    

}
