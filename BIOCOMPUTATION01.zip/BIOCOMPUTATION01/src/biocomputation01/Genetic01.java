package biocomputation01;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

public class Genetic01 {

    //Population size
    public static final int P = 250;
    //Gene size
    public static final int N = 35;
    //Number of rules
    public static final int R = 5;
    //Number of generations
    public static final int G = 200;
    //Crossover probability
    public static final double PC = 1.0;
    //Mutation probability
    public static final double PM = 0.1;

    public static void main(String[] args) throws IOException {

        try (FileWriter fw = new FileWriter("Genetic Algorithm.csv")) {
            fw.append("Generation,Best Fitness,Average Fitness\n");

            Individual population[] = new Individual[P];
            Individual parent[] = new Individual[P];
            Individual offspring[] = new Individual[P];
            Rules trainingRule[] = new Rules[64];
            Random rn = new Random();

            //Initialise arrays
            for (int i = 0; i < P; i++) {
                population[i] = new Individual();
                offspring[i] = new Individual();
            }

            for (int i = 0; i < 64; i++) {
                trainingRule[i] = new Rules();
            }

            trainingData("data2.txt", trainingRule);

            //Initialise population with random candidate solutions
            for (int i = 0; i < P; i++) {
                for (int j = 0; j < N; j++) {
                    int n = rn.nextInt(2);
                    population[i].setElement(j, n);
                }
                population[i].setFitness(0);
            }

            //Evaluate fitness of candidate rules
            evaluateFitness(population, trainingRule);

            //Output stuff
            int highest = getHighest(population);
            int average = getAverage(population);
            fw.append("0," + highest + "," + average + "\n");


            //Genetic Algorithm is repeated G times here
            for (int n = 0; n < G; n++) {

                //Select parents
                for (int i = 0; i < P; i++) {
                    int p1 = rn.nextInt(P);
                    int p2 = rn.nextInt(P);
                    if (population[p1].getFitness() >= population[p2].getFitness()) {
                        parent[i] = Clone(population[p1]);
                    } else {
                        parent[i] = Clone(population[p2]);
                    }
                }
                
                //Elitism
                offspring[0] = selectSurvivor(population);
                
                //Recombine pairs of parents
                int cross = rn.nextInt(N);
                crossOver(parent, offspring, cross);

                //Mutate the resulting offspring
                Mutate(offspring);

                //Evaluate fitness of new candidate rules
                evaluateFitness(offspring, trainingRule);

                //Output stuff G times
                highest = getHighest(offspring);
                average = getAverage(offspring);
                fw.append((n + 1) + "," + highest + "," + average + "\n");

                //Offspring becomes the new population
                population = offspring;
            }//main loop
            
            //Outputs the fittest individual as a number of candidate rules
            int best = getHighest(population);
            String bestGene = null;
            Rules bestRule[] = new Rules[10];
            for (int x = 0; x < R; x++) {
                bestRule[x] = new Rules();
            }
            for (int h = 0; h < P; h++) {
                if (population[h].getFitness() == highest) {
                    candidateData(population[h], bestRule);
                    for (int p = 0; p < R; p++) {
                        String ruless = bestRule[p].toString();
                        int actionss = bestRule[p].getAction();
                        System.out.println(ruless + " : " + actionss);
                    }
                    break;
                }
            }
            
            System.out.println("Fitness of this individual is: " + best);
            fw.flush();
        }//try
    }//method main

    public static void evaluateFitness(Individual[] population, Rules[] training) {
    //This is the fitness function

        for (int i = 0; i < P; i++) { //for every population

            int fitness = 0;
            Rules candidateRules[] = new Rules[R]; //create and initialise a new array of Rules object

            for (int n = 0; n < R; n++) {
                candidateRules[n] = new Rules();
            }

            candidateData(population[i], candidateRules); //turn the gene into candidate rules

            for (int j = 0; j < 64; j++) { //for every training rule

                for (int k = 0; k < R; k++) {//for every candidate rule
                    int count = 0;
                    for (int l = 0; l < 6; l++) {//for every bit of the rule
                        if (candidateRules[k].getElement(l) == training[j].getElement(l) || candidateRules[k].getElement(l) == 2) {//check if candidate matches the training or wildcard
                            count++;
                        }
                    }
                    if (count == 6) {
                        if (candidateRules[k].getAction() == training[j].getAction()) {//check if candidate action matches with trainnig
                            fitness++;
                        }
                        break;
                    }
                }
            }
            population[i].setFitness(fitness);
        }
    }//method evaluateFitness

    public static int getAverage(Individual[] population) {
        //Does what the method says
        int average = 0;
        for (int i = 0; i < P; i++) {
            average = average + population[i].getFitness();
        }
        average = average / P;
        return average;
    }//method getAverage

    public static int getHighest(Individual[] population) {
        //Does what the method says
        int highest = 0;
        for (int i = 0; i < P; i++) {
            if (population[i].getFitness() > highest) {
                highest = population[i].getFitness();
            }
        }
        return highest;
    }//method getHighest

    public static void crossOver(Individual[] parents, Individual[] offsprings, int crossPoint) {

        Random rn = new Random();

        for (int i = 1; i < P - 1; i = i + 2) {
            Individual p1 = parents[rn.nextInt(P)];
            Individual p2 = parents[rn.nextInt(P)];

            if (Math.random() < PC) { //crossover if within probability range
                //single point crossover
                for (int j = 0; j < N; j++) {
                    if (j <= crossPoint) { // recombine the genes of p1 and p2 to create 2 offspring
                        offsprings[i].setElement(j, p2.getElement(j));
                        offsprings[i + 1].setElement(j, p1.getElement(j));
                    } else {
                        offsprings[i + 1].setElement(j, p2.getElement(j));
                        offsprings[i].setElement(j, p1.getElement(j));
                    }
                }
            }
        }
    }//method crossOver

    public static void Mutate(Individual[] off) {
        Random rn = new Random();
        
        for (int i = 1; i < P; i++) { //if within the mutation probability range
            for (int j = 0; j < N - 6; j = j + 7) {
                if (rn.nextDouble() < PM) { //set the first 6 digits between 0 and 2, where 2 is the wildcard
                    off[i].setElement(j, rn.nextInt(3));
                    off[i].setElement(j+1, rn.nextInt(3));
                    off[i].setElement(j+2, rn.nextInt(3));
                    off[i].setElement(j+3, rn.nextInt(3));
                    off[i].setElement(j+4, rn.nextInt(3));
                    off[i].setElement(j+5, rn.nextInt(3));
                    off[i].setElement(j+6, rn.nextInt(2)); //set the last digit between 0 and 1, to prevent meaningless offspring like 222222 2
                }
            }
        }
    }//method Mutate

    public static Individual selectSurvivor(Individual[] original) {

        Individual survivor = null;
        int highest = 0;
        for (int i = 0; i < P; i++) {
            if (original[i].getFitness() > highest) {
                highest = original[i].getFitness();
                survivor = Clone(original[i]); //clones the individual with the highest fitness from the parent population
            }
        }
        return survivor;
    }//method selectSurvivor

    public static Individual Clone(Individual old) {
        Individual clonedIndividual = new Individual();
        for (int i = 0; i < N; i++) {
            clonedIndividual.setElement(i, old.getElement(i));
        }
        clonedIndividual.setFitness(old.getFitness());

        return clonedIndividual; //copy an object from a primitive level
    }//method Clone

    public static void trainingData(String fileName, Rules[] training) throws IOException {
        FileReader fr = new FileReader(fileName);
        BufferedReader br = new BufferedReader(fr);
        String line;
        String data;
        int i = 0;
        //Read in the file and remove space in each line
        //Store the first 6 characters into array of integers
        //Store the last character into integer
        while ((line = br.readLine()) != null) {
            data = line.replaceAll("\\s+", "");
            for (int j = 0; j < 6; j++) {
                int x = data.charAt(j) - '0';
                training[i].setElement(j, x);
            }
            int y = data.charAt(6) - '0';
            training[i].setAction(y);
            i++;

        }//End while
    }//method TrainingData

    public static void candidateData(Individual gene, Rules[] rule) {

        for (int j = 0; j < (N - 6); j = j + 7) {
            int i = j / 7;
            rule[i].setElement(0, gene.getElement(j));
            rule[i].setElement(1, gene.getElement(j + 1));
            rule[i].setElement(2, gene.getElement(j + 2));
            rule[i].setElement(3, gene.getElement(j + 3));
            rule[i].setElement(4, gene.getElement(j + 4));
            rule[i].setElement(5, gene.getElement(j + 5));
            rule[i].setAction(gene.getElement(j + 6));
        }

    }
}//class
